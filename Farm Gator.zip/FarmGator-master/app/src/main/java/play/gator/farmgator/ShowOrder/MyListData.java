package play.gator.farmgator.ShowOrder;

import java.util.List;

import play.gator.farmgator.BookOrder.ProductModel;

public class MyListData {
    private String Farmername,Farmno,billamount,itemname,orderdate,orderstatus;
    public MyListData(String farmername, String farmno, String billamount, String itemname, String orderdate, String orderstatus) {
        Farmername = farmername;
        Farmno = farmno;
        this.billamount = billamount;
        this.itemname = itemname;
        this.orderdate = orderdate;
        this.orderstatus = orderstatus;
    }


    public String getBillamount() {
        return billamount;
    }

    public void setBillamount(String billamount) {
        this.billamount = billamount;
    }



    public String getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(String orderdate) {
        this.orderdate = orderdate;
    }

    public String getOrderstatus() {
        return orderstatus;
    }

    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }



    public String getFarmername() {
        return Farmername;
    }

    public void setFarmername(String farmername) {
        Farmername = farmername;
    }

    public String getFarmno() {
        return Farmno;
    }

    public void setFarmno(String farmno) {
        Farmno = farmno;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }
}
