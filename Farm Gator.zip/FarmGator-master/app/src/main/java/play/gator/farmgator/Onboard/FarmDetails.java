package play.gator.farmgator.Onboard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import play.gator.farmgator.Dashboard.Dashboard;
import play.gator.farmgator.FireStoreClass;
import play.gator.farmgator.R;
import play.gator.farmgator.SalesPerson.Registration;
import play.gator.farmgator.SalesPerson.user;
import play.gator.farmgator.SplashScreen.Splash;

public class FarmDetails extends AppCompatActivity {
    private LinearLayout parentLinearLayout;
    private List<Model> farmdata = new ArrayList<>();
    EditText acresspin;
    Spinner kharifspin,rabispin,zaidspin;
    RadioGroup type;
    int PERMISSION_ID = 44;
    Button submit;
    private RadioButton typename;
    FusedLocationProviderClient mFusedLocationClient;
    String Name;
    String Address;
    String Aadhar;
    String Mob_no;
    String Alt_no;
    String Whats_no;
    String Farmer_Id;

    String Adharpath;
    String Farmerpath;
    String Bankpath;

    String latitude,salesManId ;
    String longitude;
    List<String> rabiCrop;
    List<String> kharifCrop;
    List<String> zaidCrop;

    String push_id;

    farmer farmer;

    List <String> mylist;

    user updatedUserDetails;

    CropTypeModel cropTypeModel2;

    private DatabaseReference mDatabase;
    private FirebaseFirestore mFireStore = FirebaseFirestore.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm_details);
        parentLinearLayout=(LinearLayout) findViewById(R.id.parent_linear_layout);
        mDatabase = FirebaseDatabase.getInstance().getReference("Farmers");

        new FireStoreClass().getCropList(this);



        Bundle bundle = getIntent().getExtras();
        Farmer_Id = String.valueOf(System.currentTimeMillis());
        salesManId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Aadhar = bundle.getString("Aadhar","Default");
        Name = bundle.getString("Name","Default");
        Address = bundle.getString("Address","Default");
        Mob_no = bundle.getString("Mob_no","Default");
        Alt_no = bundle.getString("Alt_no","Default");
        Whats_no = bundle.getString("Whats_no","Default");
        Adharpath = bundle.getString("Adharpath","Default");
        Farmerpath = bundle.getString("Farmerpath","Default");
        Bankpath = bundle.getString("Bankpath","Default");

        Log.e("Adharimg",Adharpath);
        Log.e("Farmerimg",Farmerpath);
        Log.e("Bankimg",Bankpath);
        new FireStoreClass().getSalesManDetails(this);

        submit=findViewById(R.id.button_submit_list);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        getLastLocation();

        submit.setOnClickListener(v->{
            prepareFarmList(v);
            user user = new user();
            user.setId(updatedUserDetails.getId());
            user.setName(updatedUserDetails.getName());
            user.setAadhar(updatedUserDetails.getAadhar());
            user.setEmail(updatedUserDetails.getEmail());
            user.setPass(updatedUserDetails.getPass());
            user.setMob_no(updatedUserDetails.getMob_no());
            List<farmer> farmerList = updatedUserDetails.getFarmerList();
            farmer farmer = new farmer(salesManId,longitude,latitude,farmdata,Farmer_Id,Name,Address,Aadhar,Mob_no,Whats_no,Alt_no,Adharpath,Farmerpath,Bankpath);
            farmerList.add(farmer);
            user.setFarmerList(farmerList);
            new FireStoreClass().addFarmDetailToFirebase(this,user);
        });
        /*submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                farmdata.clear();
                // this counts the no of child layout
                // inside the parent Linear layout
                int count = parentLinearLayout.getChildCount();
                Log.e("count: ", String.valueOf(count));
                if(count<1)
                {
                    Toast.makeText(getApplicationContext(), "Add Farm First", Toast.LENGTH_SHORT).show();
                }
                    else {



                    for (int i = 0; i < count; i++) {
                        v = parentLinearLayout.getChildAt(i);

                        acresspin = v.findViewById(R.id.exp_spinner);
                        type = v.findViewById(R.id.typegroup);
                        kharifspin = v.findViewById(R.id.kharif_spinner);
                        rabispin = v.findViewById(R.id.rabi_spinner);

                        int selectedId = type.getCheckedRadioButtonId();
                        // create an object of Language class
                        //ArrayList<String> languages = new ArrayList<String>();
                        if(selectedId==-1){
                            Toast.makeText(FarmDetails.this, "Select Your Type First", Toast.LENGTH_SHORT).show();

                        }
                        else{

                            typename = (RadioButton) findViewById(selectedId);

//                        Model model = new Model();
//                        model.acres = acresspin.getText().toString();
//                        model.type = "";//typename.getText().toString();
//                        model.kharif =""; //kharifspin.getSelectedItem().toString();
//                        model.rabi = "";//rabispin.getSelectedItem().toString();


                        String Acre = acresspin.getText().toString();
                        String Type = typename.getText().toString();
                        String Kharif = kharifspin.getSelectedItem().toString();
                        String Rabi = rabispin.getSelectedItem().toString();
                        // add the data to arraylist
                        farmdata.add(Acre);
                        farmdata.add(Type);
                        farmdata.add(Kharif);
                        farmdata.add(Rabi);
                            Log.e("farmdatasizee", String.valueOf(farmdata.size()));

//                        if(farmdata.size()%4==0){
//                            mDatabase.addValueEventListener(new ValueEventListener() {
//                                @Override
//                                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                                    // inside the method of on Data change we are setting
//                                    // our object class to our database reference.
//                                    // data base reference will sends data to firebase.
//                                    mDatabase.child("farmdata").setValue(farmdata);
//
//                                    // after adding this data we are showing toast message.
//                                    Toast.makeText(FarmDetails.this, "data added", Toast.LENGTH_SHORT).show();
//                                }
//
//                                @Override
//                                public void onCancelled(@NonNull DatabaseError error) {
//                                    // if the data is not added or it is cancelled then
//                                    // we are displaying a failure toast message.
//                                    Toast.makeText(FarmDetails.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
//                                }
//                            });
//
                       // }

//                            Map<String, String> hasMap = new HashMap<>();
//
//                            hasMap.put("Farmerid", Farmer_Id);
//                            hasMap.put("Name", Name);
//                            hasMap.put("Aadhar", Aadhar);
//                            hasMap.put("Address", Address);
//                            hasMap.put("Mob_no", Mob_no);
//                            hasMap.put("Whats_no", Whats_no);
//                            hasMap.put("Alt_no", Alt_no);
//                            hasMap.put("Aadhar_img_uri", Adharpath);
//                            hasMap.put("Farmer_img_uri", Farmerpath);
//                            hasMap.put("Bank_img_uri", Bankpath);
//                            mDatabase.setValue(hasMap).addOnCompleteListener(new OnCompleteListener<Void>() {
//                                @Override
//                                public void onComplete(@NonNull Task<Void> task) {
//                                    Toast.makeText(FarmDetails.this, "Data successfully inserted", Toast.LENGTH_SHORT).show();
//                                }
//                            });



//                            mylist = new ArrayList<>();
//                            mylist.add("12pm");
//                            mylist.add("11pm");





//                            push_id = mDatabase.child("Farmers").push().getKey();
//                            Log.d("Tag",push_id);



                            //pushFarmData(push_id);



//                            Log.v("creator", farmer);
//                        Log.e("Member acres: ", farmdata.get(i).acres);
//                        Log.e("Member type: ", farmdata.get(i).type);
//                        Log.e("Member kharif: ", farmdata.get(i).kharif);
//                        Log.e("Member rabi: ", farmdata.get(i).rabi);
                        }
                    }

                    mDatabase.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            // inside the method of on Data change we are setting
                            // our object class to our database reference.
                            // data base reference will sends data to firebase.
                            farmer= new farmer(longitude,latitude,farmdata,Farmer_Id,Name,Address,Aadhar,Mob_no,Whats_no,Alt_no,Adharpath,Farmerpath,Bankpath);
                            mDatabase.setValue(farmer);

                            // after adding this data we are showing toast message.
                            Toast.makeText(FarmDetails.this, "data added", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            // if the data is not added or it is cancelled then
                            // we are displaying a failure toast message.
                            Toast.makeText(FarmDetails.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
                        }
                    });


//
//                    mDatabase.push().setValue(farmer);
                   // Toast.makeText(FarmDetails.this, "data added", Toast.LENGTH_SHORT).show();
                }
            }
        });*/




    }
    private void prepareFarmList(View v) {
        // this counts the no of child layout
        // inside the parent Linear layout
         int count = parentLinearLayout.getChildCount();
        Log.e("count: ", String.valueOf(count));
        if (count < 1) {
            Toast.makeText(getApplicationContext(), "Add Farm First", Toast.LENGTH_SHORT).show();
        } else {


            for (int i = 0; i < count; i++) {
                v = parentLinearLayout.getChildAt(i);

                acresspin = v.findViewById(R.id.exp_spinner);
                type = v.findViewById(R.id.typegroup);
                kharifspin = v.findViewById(R.id.kharif_spinner);
                rabispin = v.findViewById(R.id.rabi_spinner);
                zaidspin = v.findViewById(R.id.zaid_spinner);

                int selectedId = type.getCheckedRadioButtonId();

                //ArrayList<String> languages = new ArrayList<String>();
                if (selectedId == -1) {
                    Toast.makeText(FarmDetails.this, "Select Your Type First", Toast.LENGTH_SHORT).show();

                } else {

                    typename = (RadioButton) findViewById(selectedId);


                    String Acre = acresspin.getText().toString();
                    String Type = typename.getText().toString();
                    String Kharif = kharifspin.getSelectedItem().toString();
                    String Rabi = rabispin.getSelectedItem().toString();
                    String Zaid = zaidspin.getSelectedItem().toString();
                    // add the data to arraylist
                    farmdata.add(new Model(String.valueOf(System.currentTimeMillis() + i),Type,Acre,Kharif,Rabi,Zaid));
                    Log.e("farmdatasizee", String.valueOf(farmdata.size()));
                }
            }
        }
    }

    public void getCropList(CropTypeModel cropTypeModel){

                        rabiCrop = cropTypeModel.getRabi();
                    kharifCrop = cropTypeModel.getKharif();
                    zaidCrop = cropTypeModel.getZaid();

    }



    private void pushFarmData(String push_id) {

        Log.d("Tag1",push_id);

        DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("Farmers").child(push_id);
        dbref.setValue(farmdata);

    }
    public void getUpdatedUserDetails(user user){
        updatedUserDetails = user;
    }

    @SuppressLint("MissingPermission")
    private void getLastLocation(){
        if (checkPermissions()) {
            if (isLocationEnabled()) {
                mFusedLocationClient.getLastLocation().addOnCompleteListener(
                        new OnCompleteListener<Location>() {
                            @Override
                            public void onComplete(@NonNull Task<Location> task) {
                                Location location = task.getResult();
                                //LatLng mycordinates=new LatLng(location.getLatitude(),location.getLongitude());

                                if (location == null) {
                                    requestNewLocationData();
                                } else {

                                    Log.e("Lattitude: ", String.valueOf(location.getLatitude()));
                                    Log.e("Longitude", String.valueOf(location.getLongitude()));

                                    latitude = String.valueOf(location.getLatitude());
                                    longitude = String.valueOf(location.getLongitude());

                                    String Cordinates="Lattitude:"+ String.valueOf(location.getLatitude())+"Longitude:"+ String.valueOf(location.getLongitude());
                                    Toast.makeText(getApplicationContext(), Cordinates, Toast.LENGTH_SHORT).show();
                                    // latTextView.setText(location.getLatitude()+"");
                                    // lonTextView.setText(location.getLongitude()+"");

                                }
                            }
                        }
                );
            } else {
                Toast.makeText(this, "Turn on location", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        } else {
            requestPermissions();
        }
    }
    public void onAddField(View v) {

        if (checkPermissions()) {
            if (isLocationEnabled()) {
                getLastLocation();
                LayoutInflater inflater=(LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                final View rowView=inflater.inflate(R.layout.field, null);
                // Add the new row before the add field button.
                parentLinearLayout.addView(rowView, parentLinearLayout.getChildCount() - 1);
               int count = parentLinearLayout.getChildCount();
                Log.e("count ::", String.valueOf(count));
                for (int i = 0; i < count; i++) {
                     v = parentLinearLayout.getChildAt(i);

                    kharifspin = v.findViewById(R.id.kharif_spinner);
                    rabispin = v.findViewById(R.id.rabi_spinner);
                    zaidspin = v.findViewById(R.id.zaid_spinner);

                    Log.e("Size ::", String.valueOf(rabiCrop.size()));
                    Log.e("List ::",String.valueOf(rabiCrop));
                    String[] wee = rabiCrop.toArray(new String[rabiCrop.size()]);
                    ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                            this, android.R.layout.simple_spinner_item, wee);
                    spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
                    rabispin.setAdapter(spinnerArrayAdapter);
                    String[] wee2 = kharifCrop.toArray(new String[kharifCrop.size()]);
                    ArrayAdapter<String> spinnerArrayAdapter2 = new ArrayAdapter<String>(
                            this, android.R.layout.simple_spinner_item, wee2);
                    spinnerArrayAdapter2.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
                    kharifspin.setAdapter(spinnerArrayAdapter2);

                    String[] wee3 = zaidCrop.toArray(new String[zaidCrop.size()]);
                    ArrayAdapter<String> spinnerArrayAdapter3 = new ArrayAdapter<String>(
                            this, android.R.layout.simple_spinner_item, wee3);
                    spinnerArrayAdapter3.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
                    zaidspin.setAdapter(spinnerArrayAdapter3);
                    // create an object of Language class
                    //ArrayList<String> languages = new ArrayList<String>();



                }
                Log.e("method caled :","yes");

                Log.e("Size ::", String.valueOf(rabiCrop.size()));
                Log.e("List ::",String.valueOf(rabiCrop));

                submit.setVisibility(View.VISIBLE);
            }else{
                Toast.makeText(getApplicationContext(), "Please Turn On Your Location First", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        }
        else{
            Toast.makeText(getApplicationContext(), "Please Accept Permission Your Location First", Toast.LENGTH_SHORT).show();
        }

    }

    @SuppressLint("MissingPermission")
    private void requestNewLocationData(){

        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(0);
        mLocationRequest.setFastestInterval(0);
        mLocationRequest.setNumUpdates(1);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mFusedLocationClient.requestLocationUpdates(
                mLocationRequest, mLocationCallback,
                Looper.myLooper()
        );

    }

    private LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            Location mLastLocation = locationResult.getLastLocation();
            // latTextView.setText(mLastLocation.getLatitude()+"");
            //  lonTextView.setText(mLastLocation.getLongitude()+"");


        }
    };

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        return false;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                PERMISSION_ID
        );
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_ID) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            }
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        if (checkPermissions()) {
            getLastLocation();
        }

    }
    public void farmDetailsAddedSuccess(){
        Toast.makeText(this,"FarmDetails Added Successfully !",Toast.LENGTH_SHORT).show();
        Intent i = new Intent(FarmDetails.this, Dashboard.class);
        startActivity(i);
        finish();
    }

}